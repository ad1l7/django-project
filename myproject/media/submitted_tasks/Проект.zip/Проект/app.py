from flask import Flask, render_template

app = Flask(__name__)


TOOLS = [
    {"id": 1, "name": "Молотки", "price": 1500, "image": "57155_middle.jpg"},
    {"id": 2, "name": "Перфораторы", "price": 3500, "image": "prosverlite-stenu-perforatorom.jpg"},
    {"id": 3, "name": "Генераторы", "price": 5000, "image": "download.jpg"},
    {"id": 4, "name": "Компрессоры", "price": 4000, "image": "downloadd.jpg"},
    {"id": 5, "name": "Пайщики труб", "price": 2500, "image": "1.jpg"},
    {"id": 6, "name": "Миксер", "price": 2500, "image": "2.jpg"}
]

BRANCHES = [
    {
        "title": "Филиал Бродского",
        "address": "143 уг ул Рыскулова",
        "phones": ["+7 (727) 275-83-47", "+7 (701) 877-22-22", "+7 (701) 726-33-11"]
    },
    {
        "title": "Филиал Жарокова",
        "address": "208 уг ул Тимирязева",
        "phones": ["+7 (778) 966-22-22", "+7 (775) 018-37-67"]
    },
    {
        "title": "Филиал Толе Би",
        "address": "293/1 уг ул Саина",
        "phones": ["+7 (701) 289-32-45", "+7 (775) 071-26-31"]
    }
]


@app.route('/')
def home():
    return render_template('index.html', tools=TOOLS, branches=BRANCHES)

if __name__ == '__main__':
    app.run(debug=True)